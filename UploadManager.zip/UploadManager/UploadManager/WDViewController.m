//
//  WDViewController.m
//  UploadManager
//
//  Created by TuanNA on 9/4/12.
//  Copyright (c) 2012 __TuanNA__. All rights reserved.
//

#import "WDViewController.h"
#import "NATUploader.h"
#import "NATUploadViewer.h"

@interface WDViewController ()

@end

@implementation WDViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NATUploadViewer *viewer = [[NATUploadViewer alloc] init];
    [viewer.view setFrame:[self.view bounds]];
    [self.view addSubview:viewer.view];
    
    // Init dummy data for create upload Request
    for (int i = 0; i < 12; i++) {
        NSString *filePath = [[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"image_0%d", i + 1] ofType:@"jpeg"];
        if (filePath) {
            NSDictionary *dic = [NSDictionary dictionaryWithObject:filePath forKey:kUploaderUserInfoFilePath];
            [[NATUploader sharedUploader] makeUpload:dic];
        }
    }
   
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
