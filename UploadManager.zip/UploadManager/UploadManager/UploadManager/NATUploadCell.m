//
//  NATUploadCell.m
//  UploadManager
//
//  Created by Nguyen Dinh Chinh on 9/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "NATUploadCell.h"
#import "NATUploadTracker.h"


@interface NATUploadCell (InternalMethods)
- (void) finishUpload;
- (void) errorUpload;
- (void) startUpload;
- (void) removeCell;
@end

@implementation NATUploadCell

@synthesize delegate = _delegate;
@synthesize uploadPhotoView = _uploadPhotoView;
@synthesize progressBar = _progressBar;
@synthesize finishedButton = _finishedButton;
@synthesize cancelButton = _cancelButton;
@synthesize refreshButton = _refreshButton;
@synthesize notifyLabel = _notifyLabel;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        _uploadPhotoView = [[UIImageView alloc] initWithFrame:CGRectMake(2, 2, 40, 40)];
        [self addSubview:_uploadPhotoView];
        
        _progressBar = [[UIProgressView alloc] initWithFrame:CGRectMake(50, 18, 230, 9)];
        [self addSubview:_progressBar];
        
        _finishedButton = [[UIButton alloc] initWithFrame:CGRectMake(288, 14, 16, 16)];
        [_finishedButton setBackgroundImage:[UIImage imageNamed:@"upload_finished.png"] forState:UIControlStateNormal];
        [_finishedButton setHidden:YES];
        [_finishedButton setBackgroundColor:[UIColor greenColor]];
        [self addSubview:_finishedButton];
        
        _cancelButton = [[UIButton alloc] initWithFrame:CGRectMake(288, 14, 16, 16)];
        [_cancelButton setBackgroundImage:[UIImage imageNamed:@"upload_cancel.png"] forState:UIControlStateNormal];
        [_cancelButton setHidden:NO];
        [_cancelButton addTarget:self action:@selector(didCancelButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_cancelButton];
        
        _refreshButton = [[UIButton alloc] initWithFrame:CGRectMake(254, 14, 16, 16)];
        [_refreshButton setBackgroundImage:[UIImage imageNamed:@"upload_refresh.png"] forState:UIControlStateNormal];
        [_refreshButton addTarget:self action:@selector(didRefreshButtonClicked::) forControlEvents:UIControlEventTouchUpInside];
        [_refreshButton setHidden:YES];
        [self addSubview:_refreshButton];
        
        _notifyLabel = [[UILabel alloc] initWithFrame:CGRectMake(52, 15, 200, 15)];
        [_notifyLabel setTextAlignment:UITextAlignmentCenter];
        [_notifyLabel setFont:[UIFont italicSystemFontOfSize:12]];
        [_notifyLabel setHidden:YES];
        [self addSubview:_notifyLabel];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void) updateCell:(NATUploadTracker *)tracker
{
    //...
    [self.uploadPhotoView setImage:[UIImage imageWithContentsOfFile:[tracker url]]];
    [self.progressBar setProgress:tracker.finishedRate];
    if (tracker.status ==  NATUploadStatusFinish) {
        [self finishUpload];
    } else if(tracker.status == NATUploadStatusFinish) {
        [self errorUpload];
    }
}   

- (void)didCancelButtonClicked:(UIButton *)sender{
    if (self.delegate && [self.delegate respondsToSelector:@selector(cancelUploadWithCell:)]) {
        [self.delegate cancelUploadWithCell:self];
    }
}

- (void)didRefreshButtonClicked:(id)sender {
    if (self.delegate && [self.delegate respondsToSelector:@selector(retryUploadWithCell:)]) {
        [self.delegate retryUploadWithCell:self];
        [self startUpload];
    }
}

- (void)dealloc {
    [_uploadPhotoView release];
    [_progressBar release];
    [_finishedButton release];
    [_cancelButton release];
    [_refreshButton release];
    [_notifyLabel release];
    [super dealloc];
}
@end

@implementation NATUploadCell (InternalMethods)

- (void) finishUpload
{
    [self.progressBar setHidden:YES];
    [self.finishedButton setHidden:NO];
    [self.finishedButton setEnabled:NO];
    [self.notifyLabel setHidden:NO];
    [self.notifyLabel setText:NSLocalizedString(@"Upload Finished!", @"")];
    [self.cancelButton setHidden:YES];
    [self.refreshButton setHidden:YES];
    [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(removeCell) userInfo:nil repeats:NO];
}

- (void) errorUpload
{
    [self.progressBar setHidden:YES];
    [self.notifyLabel setHidden:NO];
    [self.refreshButton setHidden:NO];
    [self.cancelButton setHidden:NO];
    [self.notifyLabel setText:NSLocalizedString(@"Upload Error! Try again?", @"")];
}

- (void) startUpload
{
    [self.progressBar setHidden:NO];
    [self.cancelButton setHidden:NO];
    [self.finishedButton setHidden:YES];
    [self.notifyLabel setHidden:YES];
    [self.refreshButton setHidden:YES];
}

- (void) removeCell
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(cancelUploadWithCell:)]) {
        [self.delegate cancelUploadWithCell:self];
    }
}
@end
