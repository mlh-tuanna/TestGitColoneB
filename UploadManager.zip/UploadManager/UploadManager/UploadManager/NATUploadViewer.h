//
//  NATUploadViewer.h
//  UploadManager
//
//  Created by TuanNA on 9/4/12.
//  Copyright (c) 2012 __TuanNA__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NATUploadViewer : UIViewController
{
    UITableView *uploadViewer;
    NSMutableDictionary *trackerList;
}

@end
