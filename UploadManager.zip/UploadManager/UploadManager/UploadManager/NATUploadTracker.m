//
//  NATUploadTracker.m
//  UploadManager
//
//  Created by TuanNA on 9/4/12.
//  Copyright (c) 2012 __TuanNA__. All rights reserved.
//

#import "NATUploadTracker.h"
#import "NATUploader.h"

@interface NATUploadTracker (IntenalMethods)
@end

@interface NATUploadTracker (ASIProgressDelegate) <ASIProgressDelegate>

@end

@implementation NATUploadTracker

@synthesize url = _url, delegate = _delegate, status = _status, finishedRate = _finishedRate;

- (void) setStatus:(NATUploadStatus)status
{
    _status = status;
    if (self.delegate && [self.delegate respondsToSelector:@selector(changeStatusWithUploadTracker:)]) {
        [self.delegate changeStatusWithUploadTracker:self];
    }
}

- (id) initTrackerWithURL:(NSString *) url
{
    self = [super init];
    if (self) {
        _url = url;
        _finishedRate = 0;
    }
    return self;    
}

- (void) setProgress:(float)newProgress
{
    self.finishedRate = newProgress;
//    if (self.finishedRate == 1.0) {
//        self.status = NATUploadStatusFinish;
//    }
//    else {
//        self.status = NATUploadStatusUploading;
//    }
    if (self.delegate && [self.delegate respondsToSelector:@selector(changeStatusWithUploadTracker:)]) {
        [self.delegate changeStatusWithUploadTracker:self];
    }
}

- (void) cancelUpload
{
    [[NATUploader sharedUploader] cancelUploadWithTracker:self];
}

- (void) retryUpload
{
    [[NATUploader sharedUploader] retryUploadWithTracker:self];
}

@end

@implementation NATUploadTracker (ASIProgressDelegate)

- (void) request:(ASIHTTPRequest *)request didSendBytes:(long long)bytes
{
    if (bytes < 0) {
        self.status = NATUploadStatusError;
        if (self.delegate && [self.delegate respondsToSelector:@selector(changeStatusWithUploadTracker:)]) {
            [self.delegate changeStatusWithUploadTracker:self];
        }
    }
}

- (void) request:(ASIHTTPRequest *)request incrementUploadSizeBy:(long long)newLength
{

}

@end
