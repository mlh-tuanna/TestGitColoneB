//
//  NATUploader.h
//  UploadManager
//
//  Created by TuanNA on 9/4/12.
//  Copyright (c) 2012 __TuanNA__. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString *const kUploaderTrackerInitNotification;
extern NSString *const kUploaderTrackerReleaseNotification;

extern NSString *const kUploaderTrackerInfoTracker;
extern NSString *const kUploaderUserInfoFilePath;

@class NATUploadTracker;

@interface NATUploader : NSObject

+ (id) sharedUploader;

- (void) makeUpload:(NSDictionary *) userInfo;
- (void) cancelUploadWithTracker:(NATUploadTracker *) tracker;
- (void) retryUploadWithTracker:(NATUploadTracker *) tracker;

@end
