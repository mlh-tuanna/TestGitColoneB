//
//  NATUploader.m
//  UploadManager
//
//  Created by TuanNA on 9/4/12.
//  Copyright (c) 2012 __TuanNA__. All rights reserved.
//

#import "NATUploader.h"
#import "ASIFormDataRequest.h"
#import "NATUploadTracker.h"


NSString *const kUploaderTrackerInitNotification = @"UploaderTrackerInitNotification";
NSString *const kUploaderTrackerReleaseNotification = @"UploaderTrackerReleaseNotification";

NSString *const kUploaderTrackerInfoTracker = @"UploaderTrackerInfoTracker";
NSString *const kUploaderUserInfoFilePath = @"UploaderUserInfoFilePath";

static NATUploader *uploader;

@implementation NATUploader

+(id) sharedUploader
{
    if (uploader == nil) {
        uploader = [[NATUploader alloc] init];
    }
    return uploader;
}

- (void) makeUpload:(NSDictionary *)userInfo
{
    NSString *filePath = [userInfo objectForKey:kUploaderUserInfoFilePath];
    __block NATUploadTracker *tracker = [[NATUploadTracker alloc] initTrackerWithURL:filePath];

    __block ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:[NSURL URLWithString:@"http://api.japantravel.icapps.co/posts/create"]];
    [request setFile:filePath forKey:@"post_image"];
    [request setFailedBlock:^{
        //NSLog(@"request error: %@", [request error]);
        [tracker setStatus:NATUploadStatusError];
    }];
    
    [request setCompletionBlock:^{
        ///NSLog(@"request completion: %@", [request responseString]);
        [tracker setStatus:NATUploadStatusFinish];
    }];
    
    [request setUploadProgressDelegate:tracker];
    [request startAsynchronous];
    
    NSDictionary *trackerInfo = [NSDictionary dictionaryWithObject:tracker forKey:kUploaderTrackerInfoTracker];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:kUploaderTrackerInitNotification object:nil userInfo:trackerInfo];
}

- (void) cancelUploadWithTracker:(NATUploadTracker *)tracker
{
    
}

- (void) retryUploadWithTracker:(NATUploadTracker *)tracker
{

}


@end
