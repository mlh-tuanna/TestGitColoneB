//
//  NATUploadViewer.m
//  UploadManager
//
//  Created by TuanNA on 9/4/12.
//  Copyright (c) 2012 __TuanNA__. All rights reserved.
//

#import "NATUploadViewer.h"
#import "NATUploadTracker.h"
#import "NATUploadCell.h"
#import "NATUploader.h"

@interface NATUploadViewer (InteralMethods)
- (void) addNewTracker:(NSNotification *) notification;
@end

@interface NATUploadViewer (NATUploadViewerDelegate) <NATUploadTrackerDelegate>
@end

@interface NATUploadViewer (UITableViewDelegates) <UITableViewDelegate>
@end

@interface NATUploadViewer (UITableViewDataSource) <UITableViewDataSource>
@end

@interface NATUploadViewer (NATUploadCellDelegate) <NATUploadCellDelegate>
@end

@interface NATUploadViewer (NATUploadTracker) <NATUploadTrackerDelegate>
@end

@implementation NATUploadViewer

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void) dealloc
{
    [uploadViewer release];
    [trackerList release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addNewTracker:) name:kUploaderTrackerInitNotification object:nil];
    
    trackerList = [[NSMutableDictionary alloc] init];
    uploadViewer = [[UITableView alloc] initWithFrame:[self.view bounds]];
    [uploadViewer setDelegate:self];
    [uploadViewer setDataSource:self];
    [self.view addSubview:uploadViewer];
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)viewDidUnload
{
    [[NSNotificationCenter defaultCenter] removeObject:self];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end

@implementation NATUploadViewer (InteralMethods)

- (void) addNewTracker:(NSNotification *) notification
{
    NATUploadTracker *tracker = [[notification userInfo] objectForKey:kUploaderTrackerInfoTracker];
    [tracker setDelegate:self];
    [trackerList setValue:tracker forKey:tracker.url];
    [uploadViewer reloadData];
}

@end

@implementation NATUploadViewer (UITableViewDataSource)

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSArray *keys = [trackerList allKeys];
    return [keys count];
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIndentifier = @"UploadCell";
    
    NATUploadCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIndentifier];
    if (cell == nil) {
        cell = [[[NATUploadCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIndentifier] autorelease];
        [cell setDelegate:self];
    }
    
    NSArray *keys = [trackerList allKeys];
    NSString *key = [keys objectAtIndex:indexPath.row];
    NATUploadTracker *tracker = [trackerList objectForKey:key];
    [cell updateCell:tracker];
    
    return cell;
}

@end

@implementation NATUploadViewer (NATUploadCellDelegate)

- (void) cancelUploadWithCell:(NATUploadCell *)cell;
{
    NSIndexPath *indexPath = [uploadViewer indexPathForCell:cell];
    NSArray *keyList = [trackerList allKeys];
    NSString *key = [keyList objectAtIndex:indexPath.row];
    NATUploadTracker *tracker = [trackerList objectForKey:key];
    [tracker cancelUpload];
    [trackerList removeObjectForKey:key];
    [uploadViewer beginUpdates];
    [uploadViewer deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    [uploadViewer endUpdates];
}

- (void) retryUploadWithCell:(NATUploadCell *)cell
{
    NSIndexPath *indexPath = [uploadViewer indexPathForCell:cell];
    NSArray *keys = [trackerList allKeys];
    NSString *key = [keys objectAtIndex:indexPath.row];
    NATUploadTracker *tracker = [trackerList objectForKey:key];
    [tracker retryUpload];
    
    [UIView beginAnimations:@"cancel upload" context:nil];
    [UIView setAnimationDuration:2];
    [uploadViewer reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationNone];
    [UIView commitAnimations];
}

@end

@implementation NATUploadViewer (NATUploadViewerDelegate)

- (void) changeStatusWithUploadTracker:(NATUploadTracker *)tracker
{
    NSArray *tmpArray = [trackerList allKeys];
    NSInteger theIndex = [tmpArray indexOfObject:tracker.url];
    [uploadViewer reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:theIndex inSection:0]] withRowAnimation:UITableViewRowAnimationNone];    
}

@end
