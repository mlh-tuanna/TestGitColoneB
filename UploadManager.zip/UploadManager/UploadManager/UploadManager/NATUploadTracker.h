//
//  NATUploadTracker.h
//  UploadManager
//
//  Created by TuanNA on 9/4/12.
//  Copyright (c) 2012 __TuanNA__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASIProgressDelegate.h"

typedef enum
{
    NATUploadStatusUploading,
    NATUploadStatusFinish,
    NATUploadStatusError
}NATUploadStatus;

@protocol NATUploadTrackerDelegate; 

@interface NATUploadTracker : NSObject

@property (nonatomic, retain) NSString *url;
@property (nonatomic, retain) id<NATUploadTrackerDelegate> delegate;
@property (nonatomic, assign) NATUploadStatus status;
@property (nonatomic, assign) double finishedRate;           

- (id) initTrackerWithURL:(NSString *) url;
- (void) setProgress:(float)newProgress;
- (void) cancelUpload;
- (void) retryUpload;
@end
        
@protocol NATUploadTrackerDelegate <NSObject>

@required
- (void) changeStatusWithUploadTracker:(NATUploadTracker *) tracker;
@end