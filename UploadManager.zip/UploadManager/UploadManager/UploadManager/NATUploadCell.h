//
//  NATUploadCell.h
//  UploadManager
//
//  Created by Nguyen Dinh Chinh on 9/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol NATUploadCellDelegate;
@class NATUploadTracker;

@interface NATUploadCell : UITableViewCell
@property (nonatomic, retain) id<NATUploadCellDelegate> delegate;
@property (retain, nonatomic) UIImageView *uploadPhotoView;
@property (retain, nonatomic) UIProgressView *progressBar;
@property (retain, nonatomic) UIButton *finishedButton;
@property (retain, nonatomic) UIButton *cancelButton;
@property (retain, nonatomic) UIButton *refreshButton;
@property (retain, nonatomic) UILabel *notifyLabel;

- (void) updateCell:(NATUploadTracker *) tracker;
- (void) didCancelButtonClicked:(UIButton *)sender;
- (void) didRefreshButtonClicked:(UIButton *)sender;

@end

@protocol NATUploadCellDelegate <NSObject>
- (void) cancelUploadWithCell:(NATUploadCell *) cell;
- (void) retryUploadWithCell:(NATUploadCell *) cell;
@end